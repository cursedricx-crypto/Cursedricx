/* Tamalito PWA Service Worker */
const CACHE_NAME = 'tamalito-cache-v1';
const OFFLINE_URLS = [
  './',
  './index.html',
  './manifest.json',
  './icons/icon-192.png',
  './icons/icon-512.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(OFFLINE_URLS))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(
      keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))
    ))
  );
  self.clients.claim();
});

// Estrategia: Network falling back to cache; y cache fallback cuando no hay red
self.addEventListener('fetch', (event) => {
  const req = event.request;
  event.respondWith((async () => {
    try {
      const network = await fetch(req);
      // Clonar y actualizar cache en segundo plano (excepto métodos no-GET)
      if (req.method === 'GET') {
        const cache = await caches.open(CACHE_NAME);
        cache.put(req, network.clone());
      }
      return network;
    } catch (err) {
      const cache = await caches.match(req);
      return cache || caches.match('./index.html');
    }
  })());
});
